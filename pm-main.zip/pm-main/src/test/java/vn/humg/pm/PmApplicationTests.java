package vn.humg.pm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmApplicationTests {

	@Test
	void contextLoads() {
	}

}

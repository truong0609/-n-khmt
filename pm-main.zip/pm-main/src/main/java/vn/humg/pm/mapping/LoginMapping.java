package vn.humg.pm.mapping;

public class LoginMapping {

}
